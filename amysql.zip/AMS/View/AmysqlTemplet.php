<?php include('AmysqlHeader.php'); ?>

<body id="body">
<span id="h1">AmysqlTemplet.html</span>

<p> 2012-03-15 </p>
</body>
</html>