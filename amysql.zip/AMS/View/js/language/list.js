/************************************************
 *
 * Amysql AMS
 * Amysql.com 
 * @param LanguageList  语言列表
 *
 */
var LanguageList = {
	
	'zh':{'text':'中文 - Chinese', 'UL':'使用语言', 'T':'持续时间', 'U':'用户名', 'P':'密码', 'L':'登录', 'I':'分钟', 'H':'小时', 'D':'天', 'M':'月'}
	/*, 'en':{'text':'English', 'UL':'Use Language', 'T':'Duration', 'U':'Username', 'P':'Password', 'L':'Login', 'I':'Minute', 'H':'Hour', 'D':'Day', 'M':'Month'}*/

};