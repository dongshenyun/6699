[[
	{"Name.":"{js}L.AmysqlAbout.About.name{/js}","Description.":"{js}printf(L.AmysqlAbout.About.value, {'br':'<br/>'}){/js}"},
	{"Name.":"{js}L.AmysqlAbout.Sort.name{/js}","Description.":"{js}L.AmysqlAbout.Sort.value{/js}"},
	{"Name.":"{js}L.AmysqlAbout.version.name{/js}","Description.":"{js}L.AmysqlAbout.version.value{/js}"},
	{"Name.":"{js}L.AmysqlAbout.PostTime.name{/js}","Description.":"{js}L.AmysqlAbout.PostTime.value{/js}"},
	{"Name.":"{js}L.AmysqlAbout.ProgrammingLanguage.name{/js}","Description.":"{js}L.AmysqlAbout.ProgrammingLanguage.value{/js}"},
	{"Name.":"{js}L.AmysqlAbout.SupportedPlatforms.name{/js}","Description.":"{js}L.AmysqlAbout.SupportedPlatforms.value{/js}"},
	{"Name.":"{js}L.AmysqlAbout.LicenseAgreement.name{/js}","Description.":"{js}L.AmysqlAbout.LicenseAgreement.value{/js}"},
	{"Name.":"{js}L.AmysqlAbout.OfficialWebsite.name{/js}","Description.":"{js}L.AmysqlAbout.OfficialWebsite.value{/js}"}
]
,0.0001,8,[{"name":"Name.","table":"help","def":"","max_length":2,"not_null":1,"primary_key":1,"multiple_key":0,"unique_key":0,"numeric":1,"blob":0,"type":"int","unsigned":0,"zerofill":0},{"name":"Description.","table":"help","def":"","max_length":15,"not_null":1,"primary_key":0,"multiple_key":0,"unique_key":0,"numeric":0,"blob":0,"type":"string","unsigned":0,"zerofill":0}],[""]]